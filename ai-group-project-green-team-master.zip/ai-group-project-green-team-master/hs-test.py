print('hello,world')
print('hello,github')
